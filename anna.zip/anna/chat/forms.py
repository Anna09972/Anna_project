from django import forms
from .models import *
class RegisterForm(forms.ModelForm):
    class Meta:
        model=Register
        fields=['username','email','password','image','phone_number']


class HotelForm(forms.ModelForm):
    class Meta:
        model=Hotel
        fields=['name','location','price_per_night','available_rooms']


class BookingForm(forms.ModelForm):
    class Meta:
        model=Booking
        fields=['hotel','customer_name','check_in','check_out','rooms_booked','booking_date']


