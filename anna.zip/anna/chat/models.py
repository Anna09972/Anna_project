from django.db import models

# Create your models here.
from django.contrib.auth.models import AbstractUser
class Register(AbstractUser):
    usertype=models.CharField(max_length=100,null=True,default='admin')
    image=models.FileField(upload_to='profile_image',null=True)
    phone_number=models.PositiveIntegerField(default=0,null=True)
    



class Hotel(models.Model):
    name=models.CharField(max_length=100)
    location=models.CharField(max_length=100)
    price_per_night=models.DecimalField(max_digits=8,decimal_places=2)
    available_rooms=models.IntegerField()
   
    def __str__(self):
        return self.name



class Booking(models.Model):
    hotel=models.ForeignKey(Hotel,on_delete=models.CASCADE)
    customer_name=models.CharField(max_length=100)
    check_in=models.DateField()
    check_out=models.DateField()
    rooms_booked=models.IntegerField()
    booking_date=models.DateTimeField(null=True)

    def __str__(self):
        return f"{self.customer_name} - {self.hotel.name}"