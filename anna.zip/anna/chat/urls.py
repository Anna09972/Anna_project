from django.urls import path
from .import views
urlpatterns=[
    path('chat/',views.chat,name='chat'),
    path('',views.home_page,name='index'),
    path('about',views.about,name='index'),
    path('register',views.register,name='register'),
    path('login',views.Login,name='login'),
    path('hotel',views.add_hotel,name='hotel'),
]